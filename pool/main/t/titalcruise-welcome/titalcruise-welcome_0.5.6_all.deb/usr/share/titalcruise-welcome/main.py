#!/usr/bin/python3
"""Titalcruise Welcome: bienvenida y centro de control básico."""

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib, Gtk, Gio

APP_ID = "ar.titalcruise.Welcome"
APP_VERSION = "0.5.6"
CONFIG_DIR = Path(GLib.get_user_config_dir()) / "titalcruise"
STATE_FILE = CONFIG_DIR / "welcome-state.json"
USER_AUTOSTART_DIR = Path(GLib.get_user_config_dir()) / "autostart"
AUTOSTART_OVERRIDE = USER_AUTOSTART_DIR / "titalcruise-welcome.desktop"


def default_state():
    return {
        "schema_version": 1,
        "completed": False,
        "last_completed_version": None,
        "preferences": {"open_center_on_launch": False},
    }


def read_state():
    """Read per-user state; tolerate missing, malformed, or old files."""
    default = default_state()
    try:
        with STATE_FILE.open(encoding="utf-8") as stream:
            data = json.load(stream)
        if not isinstance(data, dict):
            return default
        result = default.copy()
        result.update(data)
        if not isinstance(result.get("completed"), bool):
            result["completed"] = False
        if not isinstance(result.get("preferences"), dict):
            result["preferences"] = default["preferences"].copy()
        return result
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return default


def write_state(state):
    """Atomically save state with private per-user permissions."""
    CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        os.chmod(CONFIG_DIR, 0o700)
    except OSError:
        pass
    temporary = STATE_FILE.with_name(STATE_FILE.name + ".tmp")
    payload = json.dumps(state, ensure_ascii=False, indent=2) + "\n"
    with temporary.open("w", encoding="utf-8") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(temporary, 0o600)
    temporary.replace(STATE_FILE)


def disable_future_autostart_for_user():
    """Override the system autostart entry for this user after completion."""
    USER_AUTOSTART_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    override = (
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=Titalcruise Welcome\n"
        "Hidden=true\n"
    )
    temporary = AUTOSTART_OVERRIDE.with_name(AUTOSTART_OVERRIDE.name + ".tmp")
    temporary.write_text(override, encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(AUTOSTART_OVERRIDE)


def enable_autostart_for_user():
    """Remove the per-user suppression when the user explicitly restarts."""
    try:
        AUTOSTART_OVERRIDE.unlink()
    except FileNotFoundError:
        pass


def set_user_autostart_enabled(enabled):
    """Configure automatic launch for this user only."""
    if not enabled:
        disable_future_autostart_for_user()
        return

    USER_AUTOSTART_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    entry = (
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=Titalcruise Welcome\n"
        "Comment=Abrir el centro de control al iniciar sesión\n"
        "Exec=/usr/bin/titalcruise-welcome --center\n"
        "Terminal=false\n"
        "NoDisplay=true\n"
        "X-GNOME-Autostart-enabled=true\n"
    )
    temporary = AUTOSTART_OVERRIDE.with_name(
        AUTOSTART_OVERRIDE.name + ".tmp"
    )
    temporary.write_text(entry, encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(AUTOSTART_OVERRIDE)


def is_user_autostart_enabled():
    """Read the effective per-user preference."""
    try:
        entry = AUTOSTART_OVERRIDE.read_text(encoding="utf-8")
    except FileNotFoundError:
        # The system entry only performs the initial welcome.
        return not read_state().get("completed", False)

    values = {}
    for line in entry.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()

    if values.get("Hidden", "").lower() == "true":
        return False
    if "--center" in values.get("Exec", ""):
        return values.get("X-GNOME-Autostart-enabled", "true").lower() != "false"
    return False


def reset_state():
    state = default_state()
    write_state(state)
    enable_autostart_for_user()


def read_os_release():
    values = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as stream:
            for line in stream:
                if "=" in line:
                    key, value = line.rstrip().split("=", 1)
                    values[key] = value.strip().strip('"').strip("'")
    except OSError:
        pass
    return values


def system_summary():
    release = read_os_release()
    cpu = "No detectada"
    memory = "No disponible"
    try:
        with open("/proc/cpuinfo", encoding="utf-8") as stream:
            for line in stream:
                if line.lower().startswith("model name"):
                    cpu = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    try:
        with open("/proc/meminfo", encoding="utf-8") as stream:
            for line in stream:
                if line.startswith("MemTotal:"):
                    memory = f"{int(line.split()[1]) / 1024 / 1024:.1f} GiB"
                    break
    except (OSError, ValueError, IndexError):
        pass
    return [
        ("Sistema", release.get("PRETTY_NAME", "Sistema desconocido")),
        ("Escritorio", os.environ.get("XDG_CURRENT_DESKTOP", "No detectado")),
        ("Kernel", platform.release()),
        ("Arquitectura", platform.machine()),
        ("CPU", cpu),
        ("Memoria RAM", memory),
    ]


def command_exists(*commands):
    return next((shutil.which(command) for command in commands if shutil.which(command)), None)


def launch_command(parent, args, description):
    """Launch an installed desktop tool without invoking a shell."""
    try:
        Gio.Subprocess.new(args, Gio.SubprocessFlags.NONE)
    except (GLib.Error, OSError) as error:
        dialog = Adw.AlertDialog(
            heading="No se pudo abrir la herramienta",
            body=f"{description}\n\n{error}",
        )
        dialog.add_response("ok", "Aceptar")
        dialog.present(parent)


class WelcomeWindow(Adw.ApplicationWindow):
    def __init__(self, app, start_in_center=False):
        super().__init__(application=app)
        self.set_title("Titalcruise Welcome")
        self.set_default_size(820, 600)
        self.set_size_request(560, 440)
        self.current_page = 0

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.header = Adw.HeaderBar()
        self.header_title = Gtk.Label(label="Titalcruise Welcome")
        self.header_title.add_css_class("title")
        self.header.set_title_widget(self.header_title)
        self.center_button = Gtk.Button(label="Centro de control")
        self.center_button.connect("clicked", self.show_control_center)
        self.header.pack_end(self.center_button)
        outer.append(self.header)

        self.main_stack = Gtk.Stack()
        self.main_stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.main_stack.set_transition_duration(160)
        self.main_stack.set_vexpand(True)
        self.main_stack.add_named(self.build_wizard(), "wizard")
        self.main_stack.add_named(self.build_control_center(), "control")
        outer.append(self.main_stack)
        self.set_content(outer)

        self.show_wizard() if not start_in_center else self.show_control_center()
        self.connect("close-request", self.on_close_request)

    def build_wizard(self):
        container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.wizard_stack = Gtk.Stack()
        self.wizard_stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.wizard_stack.set_transition_duration(180)
        self.wizard_stack.set_vexpand(True)
        self.wizard_stack.set_hexpand(True)

        self.pages = [
            ("Bienvenido a TitalcruiseOS", "Tu sistema está listo para empezar.",
             "Conocé tu escritorio, descubrí herramientas útiles y consultá información de tu equipo."),
            ("Personalizá tu escritorio", "Apariencia y experiencia",
             "Abrí los ajustes de apariencia para elegir las opciones disponibles en esta instalación."),
            ("Conocé tu equipo", "Información del sistema", ""),
            ("Tus herramientas", "Accesos rápidos",
             "Encontrá rápidamente Configuración, archivos y terminal cuando estén instalados."),
            ("Tus preferencias", "Vos elegís",
             "La bienvenida se recuerda por usuario. Podés volver a abrirla manualmente cuando quieras."),
            ("¡Todo listo!", "Bienvenido a tu escritorio",
             "Terminá el recorrido para guardar tu progreso. También podés explorar el centro de control."),
        ]
        for index, (title, subtitle, description) in enumerate(self.pages):
            page = self.make_wizard_page(
                index, title, subtitle, description
            )

            if index == 4:
                scroller = Gtk.ScrolledWindow()
                scroller.set_policy(
                    Gtk.PolicyType.NEVER,
                    Gtk.PolicyType.AUTOMATIC,
                )
                scroller.set_propagate_natural_height(False)
                scroller.set_vexpand(True)
                scroller.set_child(page)
                page = scroller

            self.wizard_stack.add_named(page, f"page-{index}")

        container.append(self.wizard_stack)

        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        footer.set_margin_top(14)
        footer.set_margin_bottom(18)
        footer.set_margin_start(24)
        footer.set_margin_end(24)
        self.progress = Gtk.Label(label="")
        self.progress.set_xalign(0)
        self.progress.set_hexpand(True)
        footer.append(self.progress)
        self.back_button = Gtk.Button(label="Atrás")
        self.back_button.connect("clicked", self.go_back)
        footer.append(self.back_button)
        self.next_button = Gtk.Button(label="Comenzar")
        self.next_button.add_css_class("suggested-action")
        self.next_button.connect("clicked", self.go_next)
        footer.append(self.next_button)
        container.append(footer)
        self.update_page_controls()
        return container

    def make_wizard_page(self, index, title, subtitle, description):
        page = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=18,
        )
        page.set_valign(Gtk.Align.CENTER)
        page.set_halign(Gtk.Align.CENTER)
        page.set_margin_start(28)
        page.set_margin_end(28)
        page.set_margin_top(20)
        page.set_margin_bottom(20)

        icons = [
            "go-home-symbolic",
            "preferences-desktop-theme-symbolic",
            "computer-symbolic",
            "applications-system-symbolic",
            "preferences-system-symbolic",
            "object-select-symbolic",
        ]

        if index == 0:
            logo_path = Path(__file__).resolve().parent / "titalcruiseos-logo.png"
            if not logo_path.is_file():
                logo_path = (
                    Path(__file__).resolve().parents[2]
                    / "resources"
                    / "titalcruiseos-logo.png"
                )

            icon = Gtk.Image.new_from_file(str(logo_path))
            icon.set_pixel_size(300)
            icon.set_size_request(300, 90)
            icon.set_halign(Gtk.Align.CENTER)
            icon.set_valign(Gtk.Align.CENTER)
        else:
            icon = Gtk.Image.new_from_icon_name(icons[index])
            icon.set_pixel_size(56)
            icon.set_halign(Gtk.Align.CENTER)

        page.append(icon)

        heading = Gtk.Label(label=title)
        heading.add_css_class("title-1")
        heading.set_wrap(True)
        heading.set_justify(Gtk.Justification.CENTER)
        heading.set_max_width_chars(48)
        page.append(heading)

        subheading = Gtk.Label(label=subtitle)
        subheading.add_css_class("title-3")
        subheading.set_wrap(True)
        subheading.set_justify(Gtk.Justification.CENTER)
        page.append(subheading)

        # Tarjeta interior con márgenes reales.
        card = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=14,
        )
        card.add_css_class("card")
        card.set_hexpand(True)
        card.set_halign(Gtk.Align.FILL)

        inner = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        inner.set_margin_top(18)
        inner.set_margin_bottom(18)
        inner.set_margin_start(18)
        inner.set_margin_end(18)
        card.append(inner)

        if index == 2:
            for key, value in system_summary():
                row = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL,
                    spacing=16,
                )
                row.set_halign(Gtk.Align.FILL)

                label = Gtk.Label(label=f"{key}:")
                label.set_xalign(0)
                label.set_width_chars(17)
                label.set_valign(Gtk.Align.START)
                label.add_css_class("heading")

                val = Gtk.Label(label=value)
                val.set_xalign(0)
                val.set_wrap(True)
                val.set_hexpand(True)

                row.append(label)
                row.append(val)
                inner.append(row)
        elif index == 4:
            interface = Gio.Settings.new("org.gnome.desktop.interface")
            sound = Gio.Settings.new("org.gnome.desktop.sound")
            mouse = Gio.Settings.new("org.gnome.desktop.peripherals.mouse")
            keyboard = Gio.Settings.new(
                "org.gnome.desktop.peripherals.keyboard"
            )

            intro = Gtk.Label(
                label="Personalizá cómo se ve y se siente tu escritorio."
            )
            intro.set_wrap(True)
            intro.set_xalign(0)
            intro.add_css_class("dim-label")
            inner.append(intro)

            def add_switch(title, detail, active, callback):
                row = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL,
                    spacing=16,
                )
                row.set_hexpand(True)

                texts = Gtk.Box(
                    orientation=Gtk.Orientation.VERTICAL,
                    spacing=4,
                )
                texts.set_hexpand(True)

                heading = Gtk.Label(label=title)
                heading.set_xalign(0)
                heading.set_wrap(True)
                heading.add_css_class("heading")

                explanation = Gtk.Label(label=detail)
                explanation.set_xalign(0)
                explanation.set_wrap(True)
                explanation.add_css_class("dim-label")

                texts.append(heading)
                texts.append(explanation)

                toggle = Gtk.Switch()
                toggle.set_valign(Gtk.Align.CENTER)
                toggle.set_active(active)
                toggle.connect("notify::active", callback)

                row.append(texts)
                row.append(toggle)
                inner.append(row)

            def add_scale(title, detail, value, minimum, maximum, step, callback):
                heading = Gtk.Label(label=title)
                heading.set_xalign(0)
                heading.add_css_class("heading")
                inner.append(heading)

                explanation = Gtk.Label(label=detail)
                explanation.set_xalign(0)
                explanation.set_wrap(True)
                explanation.add_css_class("dim-label")
                inner.append(explanation)

                scale = Gtk.Scale.new_with_range(
                    Gtk.Orientation.HORIZONTAL,
                    minimum,
                    maximum,
                    step,
                )
                scale.set_hexpand(True)
                scale.set_draw_value(True)
                scale.set_value(value)
                scale.connect("value-changed", callback)
                inner.append(scale)

            add_switch(
                "Modo oscuro",
                "Usar colores oscuros en las aplicaciones compatibles.",
                interface.get_string("color-scheme") == "prefer-dark",
                lambda w, _p, s=interface: s.set_string(
                    "color-scheme",
                    "prefer-dark" if w.get_active() else "default",
                ),
            )

            add_switch(
                "Reducir animaciones",
                "Desactivar las animaciones del escritorio.",
                not interface.get_boolean("enable-animations"),
                lambda w, _p, s=interface: s.set_boolean(
                    "enable-animations", not w.get_active()
                ),
            )

            add_switch(
                "Sonidos del sistema",
                "Activar o silenciar los sonidos de eventos.",
                sound.get_boolean("event-sounds"),
                lambda w, _p, s=sound: s.set_boolean(
                    "event-sounds", w.get_active()
                ),
            )

            inner.append(Gtk.Separator(
                orientation=Gtk.Orientation.HORIZONTAL
            ))

            add_scale(
                "Velocidad del puntero",
                "Ajustá la velocidad del mouse.",
                mouse.get_double("speed"),
                -1.0, 1.0, 0.1,
                lambda w, s=mouse: s.set_double(
                    "speed", round(w.get_value(), 1)
                ),
            )

            add_scale(
                "Retardo del teclado",
                "Tiempo en milisegundos antes de repetir una tecla.",
                keyboard.get_uint("delay"),
                200, 1000, 50,
                lambda w, s=keyboard: s.set_uint(
                    "delay", int(round(w.get_value() / 50) * 50)
                ),
            )

            add_scale(
                "Tamaño del cursor",
                "Ajustá el tamaño del puntero del sistema.",
                interface.get_int("cursor-size"),
                16, 64, 4,
                lambda w, s=interface: s.set_int(
                    "cursor-size", int(round(w.get_value() / 4) * 4)
                ),
            )

            inner.append(Gtk.Separator(
                orientation=Gtk.Orientation.HORIZONTAL
            ))

            clock_heading = Gtk.Label(label="Formato del reloj")
            clock_heading.set_xalign(0)
            clock_heading.add_css_class("heading")
            inner.append(clock_heading)

            clock_description = Gtk.Label(
                label="Elegí cómo se muestra la hora en GNOME."
            )
            clock_description.set_xalign(0)
            clock_description.set_wrap(True)
            clock_description.add_css_class("dim-label")
            inner.append(clock_description)

            clock = Gtk.DropDown.new_from_strings(
                ["24 horas", "12 horas"]
            )
            clock.set_selected(
                0 if interface.get_string("clock-format") == "24h" else 1
            )
            clock.connect(
                "notify::selected",
                lambda w, _p, s=interface: s.set_string(
                    "clock-format",
                    "24h" if w.get_selected() == 0 else "12h",
                ),
            )
            inner.append(clock)

        else:
            body = Gtk.Label(label=description)
            body.set_wrap(True)
            body.set_max_width_chars(62)
            body.set_justify(Gtk.Justification.CENTER)
            body.set_halign(Gtk.Align.CENTER)
            body.add_css_class("dim-label")
            inner.append(body)

        if index == 0:
            autostart_card = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=16,
            )
            autostart_card.add_css_class("card")
            autostart_card.set_hexpand(True)

            autostart_inner = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=4,
            )
            autostart_inner.set_margin_top(14)
            autostart_inner.set_margin_bottom(14)
            autostart_inner.set_margin_start(16)
            autostart_inner.set_margin_end(16)
            autostart_inner.set_hexpand(True)

            autostart_row = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=16,
            )
            autostart_row.set_valign(Gtk.Align.CENTER)

            autostart_details = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=4,
            )
            autostart_details.set_hexpand(True)

            autostart_title = Gtk.Label(label="Inicio automático")
            autostart_title.add_css_class("heading")
            autostart_title.set_xalign(0)
            autostart_details.append(autostart_title)

            autostart_description = Gtk.Label(
                label="Abrir el centro de control al iniciar sesión."
            )
            autostart_description.set_xalign(0)
            autostart_description.set_wrap(True)
            autostart_description.add_css_class("dim-label")
            autostart_details.append(autostart_description)

            autostart_switch = Gtk.Switch()
            autostart_switch.set_valign(Gtk.Align.CENTER)
            autostart_switch.set_active(is_user_autostart_enabled())

            autostart_status = Gtk.Label(
                label=(
                    "Activado"
                    if autostart_switch.get_active()
                    else "Desactivado"
                )
            )
            autostart_status.add_css_class("dim-label")
            autostart_status.set_valign(Gtk.Align.CENTER)

            autostart_controls = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=10,
            )
            autostart_controls.set_valign(Gtk.Align.CENTER)
            autostart_controls.append(autostart_status)
            autostart_controls.append(autostart_switch)

            autostart_switch.connect(
                "notify::active",
                self.on_autostart_switch_changed,
                autostart_status,
            )

            autostart_row.append(autostart_details)
            autostart_row.append(autostart_controls)
            autostart_inner.append(autostart_row)
            autostart_card.append(autostart_inner)
            inner.append(autostart_card)

        if index == 1:
            button = Gtk.Button()
            button_content = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=8
            )
            button_content.append(
                Gtk.Image.new_from_icon_name("preferences-desktop-theme-symbolic")
            )
            button_content.append(Gtk.Label(label="Abrir Apariencia"))
            button.set_child(button_content)
            button.set_size_request(240, 48)
            button.set_halign(Gtk.Align.CENTER)
            button.add_css_class("suggested-action")
            button.connect("clicked", self.open_appearance)
            inner.append(button)

        elif index == 3:
            for label, commands, desc in self.available_tool_buttons():
                search_text = f"{label} {desc} {commands}".lower()

                if "terminal" in search_text or "consola" in search_text:
                    icon_name = "utilities-terminal-symbolic"
                elif "archivo" in search_text or "files" in search_text:
                    icon_name = "folder-symbolic"
                elif "software" in search_text or "aplicacion" in search_text:
                    icon_name = "system-software-install-symbolic"
                elif "ajuste" in search_text or "tweak" in search_text:
                    icon_name = "preferences-system-symbolic"
                else:
                    icon_name = "applications-system-symbolic"

                button = Gtk.Button()
                button.set_halign(Gtk.Align.FILL)
                button.set_hexpand(True)
                button.set_size_request(240, 48)
                button.add_css_class("pill")

                content = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL,
                    spacing=12,
                )
                content.set_halign(Gtk.Align.CENTER)

                tool_icon = Gtk.Image.new_from_icon_name(icon_name)
                tool_icon.set_pixel_size(20)

                tool_label = Gtk.Label(label=label)
                tool_label.set_wrap(True)
                tool_label.set_xalign(0)

                content.append(tool_icon)
                content.append(tool_label)
                button.set_child(content)

                button.connect(
                    "clicked",
                    self.open_tool,
                    commands,
                    desc,
                )
                inner.append(button)

        elif index == 5:
            inner.append(self.build_social_card())
            button = Gtk.Button()
            button.set_halign(Gtk.Align.CENTER)
            button.set_size_request(280, 52)
            button.add_css_class("suggested-action")

            content = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=10,
            )
            content.set_halign(Gtk.Align.CENTER)

            icon = Gtk.Image.new_from_icon_name("applications-system-symbolic")
            icon.set_pixel_size(20)

            label = Gtk.Label(label="Explorar centro de control")
            label.set_wrap(True)

            content.append(icon)
            content.append(label)
            button.set_child(content)

            button.connect("clicked", self.show_control_center)
            inner.append(button)

        page.append(card)
        return page

    def available_tool_buttons(self):
        tools = []

        candidates = [
            ("Configuración del sistema", ("gnome-control-center",),
             "Configuración de GNOME"),
            ("Archivos", ("nautilus",),
             "Administrador de archivos"),
            ("Ajustes avanzados", ("gnome-tweaks",),
             "Ajustes avanzados de GNOME"),
            ("Software", ("gnome-software",),
             "Centro gráfico de aplicaciones"),
        ]

        for label, commands, description in candidates:
            executable = command_exists(*commands)
            if executable:
                tools.append((label, [executable], description))

        terminal = command_exists("kgx", "gnome-terminal",
                                  "x-terminal-emulator")
        if terminal:
            tools.append(("Terminal", [terminal], "Terminal"))

        return tools

    def build_social_card(self):
        social_card = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        social_card.add_css_class("card")

        social_inner = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        social_inner.set_margin_top(16)
        social_inner.set_margin_bottom(16)
        social_inner.set_margin_start(16)
        social_inner.set_margin_end(16)
        social_card.append(social_inner)

        social_title = Gtk.Label(label="Nuestras redes")
        social_title.add_css_class("title-2")
        social_title.set_xalign(0)
        social_inner.append(social_title)

        social_grid = Gtk.Grid()
        social_grid.set_column_spacing(8)
        social_grid.set_row_spacing(8)
        social_grid.set_column_homogeneous(True)

        icon_dir = Path(__file__).resolve().parent
        social_links = [
            ("Instagram", "social-instagram.svg",
             "https://www.instagram.com/titalcruise/"),
            ("YouTube", "social-youtube.svg",
             "https://www.youtube.com/@Titalcruise"),
            ("TikTok", "social-tiktok.svg",
             "https://www.tiktok.com/@titalcruise"),
            ("GitHub", "social-github.svg",
             "https://github.com/Titalcruise/"),
            ("2da cuenta de Instagram", "social-instagram.svg",
             "https://www.instagram.com/titalcruise_ea/"),
        ]

        for index, (label, icon_file, uri) in enumerate(social_links):
            button = Gtk.Button()
            button.set_hexpand(True)
            button.set_tooltip_text(label)

            button_content = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=8,
            )
            button_content.set_halign(Gtk.Align.CENTER)

            icon_path = icon_dir / icon_file
            social_icon = Gtk.Image.new_from_file(str(icon_path))
            social_icon.set_pixel_size(24)
            button_content.append(social_icon)

            text_label = Gtk.Label(label=label)
            text_label.set_wrap(True)
            button_content.append(text_label)

            button.set_child(button_content)
            button.connect(
                "clicked",
                lambda _button, link=uri: self.open_social_link(link),
            )
            social_grid.attach(button, index % 3, index // 3, 1, 1)

        social_inner.append(social_grid)
        return social_card


    def build_control_center(self):
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC,
        )

        content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=20,
        )
        content.set_margin_top(24)
        content.set_margin_bottom(28)
        content.set_margin_start(28)
        content.set_margin_end(28)

        # Cabecera visual
        hero = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=16,
        )
        hero.add_css_class("card")
        hero.set_margin_bottom(4)

        emblem = Gtk.Image.new_from_icon_name(
            "applications-system-symbolic"
        )
        emblem.set_pixel_size(48)
        emblem.set_valign(Gtk.Align.CENTER)
        hero.append(emblem)

        heading_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=6,
        )
        heading_box.set_valign(Gtk.Align.CENTER)
        heading_box.set_hexpand(True)

        title = Gtk.Label(label="Centro de control")
        title.add_css_class("title-1")
        title.set_xalign(0)
        title.set_wrap(True)
        heading_box.append(title)

        intro = Gtk.Label(
            label=(
                "Todo tu escritorio TitalcruiseOS, "
                "organizado en un solo lugar."
            )
        )
        intro.set_xalign(0)
        intro.set_wrap(True)
        intro.add_css_class("dim-label")
        heading_box.append(intro)

        hero.append(heading_box)
        content.append(hero)
        def make_card(title_text, subtitle, icon_name, callback):
            # La tarjeta exterior define el aspecto visual.
            card = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=0,
            )
            card.add_css_class("card")
            card.set_hexpand(True)
            card.set_valign(Gtk.Align.FILL)

            # Este contenedor crea espacio REAL dentro de la tarjeta.
            inner = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=12,
            )
            inner.set_margin_top(16)
            inner.set_margin_bottom(16)
            inner.set_margin_start(16)
            inner.set_margin_end(16)
            inner.set_hexpand(True)
            inner.set_vexpand(True)
            card.append(inner)

            icon = Gtk.Image.new_from_icon_name(icon_name)
            icon.set_pixel_size(36)
            icon.set_halign(Gtk.Align.START)
            inner.append(icon)

            name = Gtk.Label(label=title_text)
            name.add_css_class("heading")
            name.set_xalign(0)
            name.set_wrap(True)
            inner.append(name)

            description = Gtk.Label(label=subtitle)
            description.set_xalign(0)
            description.set_wrap(True)
            description.set_valign(Gtk.Align.START)
            description.set_vexpand(True)
            description.add_css_class("dim-label")
            inner.append(description)

            button = Gtk.Button(label="Abrir")
            button.set_halign(Gtk.Align.START)
            button.connect(
                "clicked",
                lambda _button: callback(),
            )
            inner.append(button)
            return card

        # Accesos principales
        section_title = Gtk.Label(label="Accesos principales")
        section_title.add_css_class("title-2")
        section_title.set_xalign(0)
        content.append(section_title)

        sections_grid = Gtk.Grid()
        sections_grid.set_column_spacing(14)
        sections_grid.set_row_spacing(14)
        sections_grid.set_column_homogeneous(True)
        sections_grid.set_row_homogeneous(True)

        sections = [
            (
                "Apariencia",
                "Personalizá el aspecto de tu escritorio.",
                "preferences-desktop-theme-symbolic",
                self.open_appearance,
            ),
            (
                "Configuración",
                "Red, pantallas, sonido y otros ajustes.",
                "preferences-system-symbolic",
                self.open_settings,
            ),
            (
                "Mi equipo",
                "Consultá el sistema, kernel, CPU y memoria.",
                "computer-symbolic",
                self.show_system_dialog,
            ),
        ]

        for index, (name, subtitle, icon, callback) in enumerate(sections):
            card = make_card(name, subtitle, icon, callback)
            sections_grid.attach(card, index % 2, index // 2, 1, 1)

        content.append(sections_grid)

        # Herramientas detectadas en esta instalación
        tools_title = Gtk.Label(label="Tus herramientas")
        tools_title.add_css_class("title-2")
        tools_title.set_xalign(0)
        content.append(tools_title)

        tools_intro = Gtk.Label(
            label="Accesos disponibles según los programas instalados."
        )
        tools_intro.set_xalign(0)
        tools_intro.set_wrap(True)
        tools_intro.add_css_class("dim-label")
        content.append(tools_intro)

        tools_grid = Gtk.Grid()
        tools_grid.set_column_spacing(14)
        tools_grid.set_row_spacing(14)
        tools_grid.set_column_homogeneous(True)

        tool_icons = {
            "Configuración del sistema": "preferences-system-symbolic",
            "Archivos": "folder-symbolic",
            "Ajustes avanzados": "applications-system-symbolic",
            "Software": "system-software-install-symbolic",
            "Terminal": "utilities-terminal-symbolic",
        }

        tool_buttons = self.available_tool_buttons()

        if not tool_buttons:
            empty = Gtk.Label(
                label="No se detectaron herramientas compatibles."
            )
            empty.set_xalign(0)
            empty.add_css_class("dim-label")
            content.append(empty)
        else:
            for index, (name, commands, description) in enumerate(tool_buttons):
                icon_name = tool_icons.get(
                    name,
                    "application-x-executable-symbolic",
                )
                card = make_card(
                    name,
                    description,
                    icon_name,
                    lambda c=commands, d=description: self.open_tool(
                        None, c, d
                    ),
                )
                tools_grid.attach(
                    card,
                    index % 2,
                    index // 2,
                    1,
                    1,
                )

            content.append(tools_grid)

        back = Gtk.Button(label="Volver a la bienvenida")
        back.set_icon_name("go-previous-symbolic")
        back.set_halign(Gtk.Align.START)
        back.connect("clicked", lambda _button: self.show_wizard())
        content.append(back)

        scroller.set_child(content)
        return scroller

    def show_wizard(self):
        self.main_stack.set_visible_child_name("wizard")
        self.center_button.set_visible(True)
        self.header_title.set_label("Titalcruise Welcome")
        self.update_page_controls()

    def show_control_center(self, *_args):
        self.main_stack.set_visible_child_name("control")
        self.center_button.set_visible(False)
        self.header_title.set_label("Centro de control")

    def update_page_controls(self):
        self.wizard_stack.set_visible_child_name(f"page-{self.current_page}")
        self.progress.set_text(f"Paso {self.current_page + 1} de {len(self.pages)}")
        self.back_button.set_visible(self.current_page > 0)
        if self.current_page == 0:
            self.next_button.set_label("Comenzar")
        elif self.current_page == len(self.pages) - 1:
            self.next_button.set_label("Finalizar")
        else:
            self.next_button.set_label("Continuar")

    def go_back(self, _button):
        if self.current_page > 0:
            self.current_page -= 1
            self.update_page_controls()

    def go_next(self, _button):
        if self.current_page < len(self.pages) - 1:
            self.current_page += 1
            self.update_page_controls()
            return
        state = read_state()
        state["schema_version"] = 1
        state["completed"] = True
        state["last_completed_version"] = APP_VERSION
        try:
            write_state(state)
            # Respetar la preferencia elegida en el Paso 1.
            # Si no existe una preferencia personal, desactivar
            # el inicio automático del asistente ya completado.
            if not AUTOSTART_OVERRIDE.exists():
                disable_future_autostart_for_user()
        except OSError as error:
            dialog = Adw.AlertDialog(
                heading="No se pudo guardar el progreso",
                body=f"No se pudo guardar el estado o la preferencia de inicio automático.\n\n{error}",
            )
            dialog.add_response("ok", "Aceptar")
            dialog.present(self)
            return
        self.close()

    def on_autostart_switch_changed(
        self, switch, _property, status_label
    ):
        if getattr(self, "_updating_autostart_switch", False):
            return

        enabled = switch.get_active()
        try:
            set_user_autostart_enabled(enabled)
        except OSError as error:
            self._updating_autostart_switch = True
            switch.set_active(not enabled)
            self._updating_autostart_switch = False

            dialog = Adw.AlertDialog(
                heading="No se pudo cambiar el inicio automático",
                body=str(error),
            )
            dialog.add_response("ok", "Aceptar")
            dialog.present(self)
            return

        status_label.set_label(
            "Activado" if enabled else "Desactivado"
        )

    def open_social_link(self, uri):
        try:
            Gio.AppInfo.launch_default_for_uri(uri, None)
        except GLib.Error as error:
            dialog = Adw.AlertDialog(
                heading="No se pudo abrir el enlace",
                body=f"No se pudo abrir {uri}\\n\\n{error}",
            )
            dialog.add_response("ok", "Aceptar")
            dialog.present(self)

    def disable_autostart_from_center(self, _button):
        try:
            disable_future_autostart_for_user()
        except OSError as error:
            dialog = Adw.AlertDialog(
                heading="No se pudo cambiar el inicio automático",
                body=str(error),
            )
            dialog.add_response("ok", "Aceptar")
            dialog.present(self)
            return

        dialog = Adw.AlertDialog(
            heading="Inicio automático desactivado",
            body=(
                "Titalcruise Welcome ya no se iniciará automáticamente "
                "en tu próxima sesión. La aplicación sigue instalada "
                "y podés abrirla manualmente cuando quieras."
            ),
        )
        dialog.add_response("ok", "Entendido")
        dialog.present(self)

    def open_settings(self):
        if command_exists("gnome-control-center"):
            launch_command(self, ["gnome-control-center"], "Configuración del sistema")
        else:
            self.show_missing_tool("Configuración de GNOME")

    def open_appearance(self, *_args):
        if command_exists("gnome-tweaks"):
            launch_command(self, ["gnome-tweaks"], "Apariencia")
        elif command_exists("gnome-control-center"):
            launch_command(
                self,
                ["gnome-control-center", "background"],
                "Fondo de escritorio"
            )
        else:
            self.show_missing_tool("Configuración de GNOME")

    def open_tool(self, _button, commands, description):
        if command_exists(commands[0]):
            launch_command(self, commands, description)
        else:
            self.show_missing_tool(description)

    def show_missing_tool(self, name):
        dialog = Adw.AlertDialog(
            heading="Herramienta no disponible",
            body=f"No se encontró {name} en esta instalación.",
        )
        dialog.add_response("ok", "Aceptar")
        dialog.present(self)

    def show_system_dialog(self, *_args):
        body = "\n".join(f"{key}: {value}" for key, value in system_summary())
        dialog = Adw.AlertDialog(heading="Información del equipo", body=body)
        dialog.add_response("ok", "Cerrar")
        dialog.present(self)

    def on_close_request(self, _window):
        # Closing the window is not the same as completing the wizard.
        return False


class WelcomeApp(Adw.Application):
    def __init__(self, start_in_center=False):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.start_in_center = start_in_center

    def do_activate(self):
        window = self.props.active_window
        if window is None:
            window = WelcomeWindow(self, self.start_in_center)
        window.present()


def main():
    args = sys.argv[1:]
    if "--status" in args:
        print(json.dumps(read_state(), ensure_ascii=False, indent=2))
        return 0

    if "--restart" in args:
        try:
            reset_state()
        except OSError as error:
            print(f"No se pudo reiniciar el estado: {error}", file=sys.stderr)
            return 1
        print("Estado reiniciado. La bienvenida queda pendiente.")
        # Restart is an explicit user action, so open the wizard.
        args = [arg for arg in args if arg != "--restart"]

    if "--first-run" in args and read_state().get("completed") is True:
        try:
            disable_future_autostart_for_user()
        except OSError as error:
            print(
                f"Advertencia: no se pudo desactivar el inicio automático: {error}",
                file=sys.stderr,
            )
        print("Bienvenida ya completada; no se abre la ventana.")
        return 0

    start_in_center = "--center" in args
    app = WelcomeApp(start_in_center=start_in_center)
    return app.run([sys.argv[0]])


if __name__ == "__main__":
    raise SystemExit(main())
