# GruvTahoe

A dark GNOME Shell and GTK theme inspired by macOS Tahoe, built on the MacTahoe-Dark base with Gruvbox color influences.

## Features

- Dark quick settings panel with consistent dark pill buttons
- Transparent top bar
- macOS Tahoe-inspired window decorations
- Compatible with GNOME 45+
- Covers Shell, GTK-3.0, and GTK-4.0

## Installation

Clone the repo:
```bash
git clone git@github.com:mimisco-git/GruvTahoe.git
cp -r GruvTahoe ~/.themes/
```

Apply with GNOME Tweaks:
- Shell: GruvTahoe
- Legacy Applications: GruvTahoe

Or via terminal:
```bash
gsettings set org.gnome.shell.extensions.user-theme name 'GruvTahoe'
gsettings set org.gnome.desktop.interface gtk-theme 'GruvTahoe'
```

## Requirements

- GNOME 45 or later
- User Themes extension enabled
- GNOME Tweaks

## Credits

- Based on MacTahoe-Dark by the MacTahoe project
- Gruvbox color palette by Pavel Pertsev
- Built and customized by mimisco-git

## License

GPL-3.0
